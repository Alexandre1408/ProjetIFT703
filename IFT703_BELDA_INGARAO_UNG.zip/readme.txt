(sgp :esc nil :ans 0.1 :bll 0.5 :rt -2)


Nous ne possèdons qu'un seul fichier lisp : tictactoe.lisp, il contient les routines lisps ansi que le modèle act-r.